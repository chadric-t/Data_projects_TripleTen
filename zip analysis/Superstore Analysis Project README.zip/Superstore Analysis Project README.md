# Superstore Analysis Project

## Tableau Public Link

https://public.tableau.com/app/profile/chadric.thomas/viz/Project4SuperstoreAnalysis\_17603260551220/ProfitsLosses3?publish=yes

## Project Summary

This analysis examines highest profit, profit loss, advertising analysis, return rates, average return rates against average profit. It includes visualizations and scatter plot charts to explain my findings.

